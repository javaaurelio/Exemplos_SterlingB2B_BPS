package br.com.cliente;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;

public class ValidarToken {
	

	public static boolean validarToken(String token, String certificaPublicaPath, String chavePrivadaPath) throws IllegalArgumentException, NoSuchAlgorithmException, IOException, InvalidKeySpecException, CertificateException {

		try {
			DecodedJWT decodedJWT;
			long start = System.currentTimeMillis();
			Algorithm algorithm = Algorithm.RSA256(CarregarChaves.getRSAPublicKey(certificaPublicaPath), CarregarChaves.getRSAPrivateKey(chavePrivadaPath));
	
			JWTVerifier verifier = JWT.require(algorithm).withIssuer("Baeldung").build();
			decodedJWT = verifier.verify(token);
	
			System.out.println("getHeader ->" + decodedJWT.getHeader());
			System.out.println("getExpiresAt ->" + decodedJWT.getExpiresAt());
			System.out.println("Processamento ->" + (System.currentTimeMillis()-start) + "ms");
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}


}
