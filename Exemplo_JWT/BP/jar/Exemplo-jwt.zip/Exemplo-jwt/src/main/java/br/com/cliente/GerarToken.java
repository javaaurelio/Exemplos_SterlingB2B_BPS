package br.com.cliente;

import java.util.Date;
import java.util.UUID;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

public class GerarToken {

	public static void main(String[] args) {
		try {

			Algorithm algorithm = Algorithm.RSA256(
					CarregarChaves.getRSAPublicKey("target/classes/pub_rsa.pem"), 
					CarregarChaves.getRSAPrivateKey("target/classes/pk_rsa.pem"));
			
			Date expiraEm = new Date(System.currentTimeMillis() + 30000L);
			String jwtToken = JWT.create()
					  .withIssuer("Baeldung")
					  .withSubject("Baeldung Details")
					  .withClaim("userId", "1234")
					  .withIssuedAt(new Date())
					  .withExpiresAt(expiraEm)
					  .withJWTId(UUID.randomUUID().toString())
//					  .withNotBefore(new Date(System.currentTimeMillis() + 1000L))
					  .sign(algorithm);
		System.out.println("Token Gerado JWT (valido ate " + expiraEm + ") :" +jwtToken);
		System.out.println("-= Finalizado com Sucesso  =- ");
		
		
		boolean valido = ValidarToken.validarToken(jwtToken, "target/classes/pub_rsa.pem", "target/classes/pk_rsa.pem");

		System.out.println("-= Validacao Token: " + valido);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
