package br.com.cliente;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

import org.apache.commons.io.FileUtils;

public class CarregarChaves {
	
	public static RSAPublicKey getRSAPublicKey(String pathFIle)
			throws IOException, NoSuchAlgorithmException, CertificateException {

		byte[] pubKeyBytes;
		File file = new File(pathFIle);
		byte[] fileToByteArray = FileUtils.readFileToByteArray(file);
		String string = new String(fileToByteArray, "UTF-8");
		String replaceAll = string.replace("-----BEGIN CERTIFICATE-----", "").replace("-----END CERTIFICATE-----", "")
				.replaceAll("\r\n", "");
		pubKeyBytes = Base64.getDecoder().decode(replaceAll);
		Certificate certificate = CertificateFactory.getInstance("X.509")
				.generateCertificate(new ByteArrayInputStream(pubKeyBytes));

		PublicKey publicKey = certificate.getPublicKey();
		System.out.println("-=Chave Publica(certificado): Sucesso =-");
		return (RSAPublicKey) publicKey;
	}

	public static RSAPrivateKey getRSAPrivateKey(String pathFIle) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

		File file = new File(pathFIle);
		byte[] fileToByteArray = FileUtils.readFileToByteArray(file);
		String string = new String(fileToByteArray, "UTF-8");

		String replaceAll = string.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "")
				.replaceAll("\r\n", "");

		byte[] prvKeyBytes = Base64.getDecoder().decode(replaceAll);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		KeySpec ks = new PKCS8EncodedKeySpec(prvKeyBytes);

		PrivateKey private1 = keyFactory.generatePrivate(ks);
		RSAPrivateKey privKey = (RSAPrivateKey) private1;
		System.out.println("-=Chave Privada: Sucesso =-");


		return privKey;
	}

}
